package com.library.service;

import com.library.model.BorrowRecord;
import com.library.model.User;
import com.library.repository.UserRepository;
import com.library.service.BorrowService;

import java.time.LocalDate;
import java.util.List;

public class UserService {

    private final UserRepository repository;

    public UserService(UserRepository repository) {
        this.repository = repository;
    }

    public User findUser(String username) {
        return repository.findByUsername(username);
    }

    public boolean canBorrow(User user) {
        return user.getFineBalance() <= 0.0;
    }

    public void payFine(User user, double amount) {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        double current = user.getFineBalance();
        if (amount >= current) {
            user.setFineBalance(0.0);
        } else {
            user.setFineBalance(current - amount);
        }
    }

    // ================================
    // Sprint 4 — Unregister user
    // ================================
    public boolean unregister(User admin, User targetUser,
                              BorrowService borrowService) {

        // Only admins can unregister
        if (admin == null || !"admin".equals(admin.getUsername())) {
            throw new SecurityException("Only admin can unregister users");
        }

        // Cannot unregister if unpaid fines exist
        if (targetUser.getFineBalance() > 0) {
            throw new IllegalStateException("User has unpaid fines");
        }

        // Cannot unregister if user has active or overdue loans
        List<BorrowRecord> loans = borrowService.getBorrowRecordsForUser(targetUser);

        for (BorrowRecord r : loans) {
            if (!r.isReturned() || r.isOverdue(LocalDate.now())) {
                throw new IllegalStateException("User has active or overdue loans");
            }
        }

        return repository.deleteUser(targetUser.getUsername());
    }
}
